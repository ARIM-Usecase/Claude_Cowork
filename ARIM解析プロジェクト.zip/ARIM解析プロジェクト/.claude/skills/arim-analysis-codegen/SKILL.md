---
name: arim-analysis-codegen
description: data/processed/ の整理済みARIMデータと、参考資料の要約（reference_summary.md）を踏まえて、EDA・信号処理・機械学習・データ分析の4種類のNotebookをoutput/に作成する。「解析コードを作って」「ノートブックを作って」「EDAして」「機械学習のコードを書いて」「データを置いたので作業して」など、データを使った解析コード作成の依頼があった場合に必ず使用する。本スキルはCLAUDE.mdで定義されたパイプラインのステップ3に該当する。ユーザーが4種類のうち1つしか明示しなかった場合でも、4種類すべてを作成するまでタスク完了としない。
---

# ARIM 解析コード生成スキル

## 目的
整理済みデータ（`data/processed/`）と参考資料の要約（`reference_summary.md`）を入力として、
4種類の解析Notebook（EDA／信号処理／機械学習／データ分析）を `output/` に作成する。

## 前提条件
- `data/processed/` にPython解析用に整理されたデータが存在する
- `data/processed/reference_summary.md`（参考資料の要約。「参考資料なし」の記録でも可）があれば読み込む。
  なければ `参考/` フォルダ内のPDFを直接確認する

`data/processed/` が存在しない、または空の場合は、本スキルを開始する前に
CLAUDE.mdのステップ1（arim-zip-organizeスキル）を先に実行すること。

## 重要: タスク完了の判定基準

ユーザーから「EDA、機械学習、信号処理、データ分析のコードを作成する」のように
**複数種類の解析を一括で依頼された場合、以下の4種類のNotebookすべてを作成して
初めてタスク完了とする**。1種類（特にEDA）だけを作成して終了してはならない。

完了チェックリスト:
- [ ] `output/01_eda.ipynb` を作成した
- [ ] `output/02_signal_processing.ipynb` を作成した（対象データがある場合）
- [ ] `output/03_machine_learning.ipynb` を作成した
- [ ] `output/04_data_analysis_summary.ipynb` を作成した
- [ ] `output/analysis_log.md` に各Notebookの内容・対応関係を記録した

各Notebookの作成が完了するごとに、上記チェックリストの状況をユーザーに報告し、
未完了の項目がある場合は続けて作成する。

## 手順

### Step 1: データとコンテキストの確認
1. `data/processed/` のディレクトリ構造とファイル形式（CSV/画像/JSON等）を確認する
2. `reference_summary.md`（または`参考/`内PDF）から以下を確認する:
   - データの種類（分光データ、画像データ、時系列データ等）
   - 参考資料で使われている解析手法・評価指標
   - 対象とすべき変数・着目すべき特徴

### Step 2: EDA Notebookの作成（`output/01_eda.ipynb`）
- データ読込、欠損値・型・分布の確認
- 基本統計量、相関、可視化（ヒストグラム、散布図、時系列プロット等）
- データ種別ごとの特徴的な可視化（例: スペクトルデータなら波形重ね描き）

### Step 3: 信号処理 Notebookの作成（`output/02_signal_processing.ipynb`）
**対象データの判定**: 分光データ、時系列データ、画像データ（SEM等）が含まれる場合に作成する。
該当データが無い場合は、`analysis_log.md` に「対象データなしのため省略」と明記する。

含める処理の例:
- スペクトル/時系列データ: スムージング（Savitzky-Golay等）、ベースライン補正、FFT、ピーク検出
- 画像データ: フィルタリング、エッジ検出、粒径分布解析、二値化・セグメンテーション

### Step 4: 機械学習 Notebookの作成（`output/03_machine_learning.ipynb`）
- 参考資料の手法に基づき、タスク（分類/回帰/クラスタリング等）を設定する
- 特徴量エンジニアリング（EDAで確認した変数を使用）
- ベースラインモデルの構築（scikit-learn等）と評価指標の算出
- 参考資料に具体的なモデル・手法の記載がある場合はそれを優先する。記載が無い場合は
  データ種別に応じた標準的な手法（例: 分光データなら回帰/分類、構造データならクラスタリング）を採用し、
  その選定理由を Notebook内にコメントで明記する

### Step 5: データ分析まとめ Notebookの作成（`output/04_data_analysis_summary.ipynb`）
- Step2〜4の結果を統合し、表・グラフでまとめる
- 参考資料の知見と今回の解析結果の比較・考察を記述する
- 今後の解析方針・追加データの必要性などを記述する

### Step 6: 解析ログの作成
`output/analysis_log.md` に以下を記録する:
- 作成した4つのNotebookとその対応関係（どのデータ・参考資料の知見を使ったか）
- 信号処理を省略した場合はその理由
- 機械学習で採用した手法とその選定理由
- 既知の課題・制限事項

## コーディング規約（CLAUDE.mdと共通）
- pandas, numpy, matplotlib/seaborn, scikit-learn を基本とする
- NumPy 2.0対応（`np.trapz` ではなく `np.trapezoid`）
- 日本語フォント表示が必要な場合はMeiryo等を明示指定
- パスはプロジェクトルートからの相対パスで記述

## 出力物
- `output/01_eda.ipynb`
- `output/02_signal_processing.ipynb`（または省略の記録）
- `output/03_machine_learning.ipynb`
- `output/04_data_analysis_summary.ipynb`
- `output/analysis_log.md`
